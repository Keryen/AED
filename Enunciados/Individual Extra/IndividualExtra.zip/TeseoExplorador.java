package aed.cnossos;

import es.upm.aedlib.Pair;
import es.upm.aedlib.positionlist.*;


public class TeseoExplorador {
    
  public static Pair<Object,PositionList<PuntoCardinal>> explora(Laberinto cnossos) {
    // Modifica este metodo
    return null;
  }
}



