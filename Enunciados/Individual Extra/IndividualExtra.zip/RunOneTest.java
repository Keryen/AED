package aed.cnossos;

public class RunOneTest {
  public static void main(String args[]) {
    TesterIndExtra.test_5();
  }
}
